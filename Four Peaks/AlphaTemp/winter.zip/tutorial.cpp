#include "tutorial.hpp"

#include "AEEngine.h"
#include "graphics.hpp"
#include "player.hpp"
#include "gamestate.hpp"
#include "sprite.hpp"
#include "level_loader.hpp"

#include <cstdint>
#include <cmath>

typedef std::uint32_t u32;
extern s8 gFontId;

namespace
{
    static void printText(f32 x, f32 y, u32 argbColor, const char* text, f32 scale = 1.0f)
    {
        f32 a = ((argbColor >> 24) & 0xFF) / 255.0f;
        f32 r = ((argbColor >> 16) & 0xFF) / 255.0f;
        f32 g = ((argbColor >> 8) & 0xFF) / 255.0f;
        f32 b = ((argbColor >> 0) & 0xFF) / 255.0f;
        AEGfxPrint(gFontId, text, x, y, scale, r, g, b, a);
    }

    static u32 getTileColor(int tileType)
    {
        switch (tileType)
        {
        case 6: return 0xFF555555u; // underground
        case 7: return 0xFF888888u; // top ground
        case 2: return 0xFFFF3333u; // spikes
        case 8: return 0xFFFFFF00u; // melon (usually drawn animated)
        default: return 0x00000000u;
        }
    }

    static void gridToWorld(int col, int row, int gridCols, int gridRows,
        float& xWorld, float& yWorld, float& cellW, float& cellH)
    {
        float minX = AEGfxGetWinMinX();
        float maxX = AEGfxGetWinMaxX();
        float minY = AEGfxGetWinMinY();
        float maxY = AEGfxGetWinMaxY();

        cellW = (maxX - minX) / static_cast<f32>(gridCols);
        cellH = (maxY - minY) / static_cast<f32>(gridRows);

        xWorld = minX + col * cellW;
        yWorld = minY + row * cellH;
    }

    static void drawGridLines(int gridCols, int gridRows)
    {
        const u32 gridColor = 0x80FFFFFF;

        float minX = AEGfxGetWinMinX();
        float maxX = AEGfxGetWinMaxX();
        float minY = AEGfxGetWinMinY();
        float maxY = AEGfxGetWinMaxY();

        float cellW = (maxX - minX) / static_cast<f32>(gridCols);
        float cellH = (maxY - minY) / static_cast<f32>(gridRows);
        float thickness = (cellW < cellH ? cellW : cellH) * 0.04f;

        for (int col = 0; col <= gridCols; ++col)
        {
            float x = minX + col * cellW;
            gfx::Vec2 pos{ x, (minY + maxY) * 0.5f };
            gfx::Vec2 size{ thickness, maxY - minY };
            gfx::drawRectangle(pos, 0.0f, size, gridColor);
        }

        for (int row = 0; row <= gridRows; ++row)
        {
            float y = minY + row * cellH;
            gfx::Vec2 pos{ (minX + maxX) * 0.5f, y };
            gfx::Vec2 size{ maxX - minX, thickness };
            gfx::drawRectangle(pos, 0.0f, size, gridColor);
        }
    }

    static void drawTilesFromMap(const int tileMap[20][32])
    {
        constexpr int gridRows = 20;
        constexpr int gridCols = 32;

        for (int row = 0; row < gridRows; ++row)
        {
            for (int col = 0; col < gridCols; ++col)
            {
                int tileType = tileMap[row][col];
                if (tileType <= 0) continue;

                float xWorld{}, yWorld{}, cellW{}, cellH{};
                gridToWorld(col, row, gridCols, gridRows, xWorld, yWorld, cellW, cellH);

                gfx::Vec2 pos{ xWorld + cellW * 0.5f, yWorld + cellH * 0.5f };
                gfx::Vec2 size{ cellW, cellH };

                pos.x = std::round(pos.x);
                pos.y = std::round(pos.y);

                // Animated tiles: melon(8), checkpoint(10), crack(1)
                if (sprite::drawAnimatedTile(tileType, pos, size))
                    continue;

                // Spikes (2)
                if (tileType == 2)
                {
                    AEGfxTexture* spikeTex = sprite::spikes();
                    if (spikeTex)
                    {
                        float heightScale = 1.5f;
                        gfx::Vec2 spikeSize{ size.x, size.y * heightScale };

                        gfx::Vec2 spikePos = pos;
                        spikePos.y += (spikeSize.y - size.y) * 0.5f;

                        gfx::drawSprite(spikeTex, spikePos, 0.0f, spikeSize, 0.0f, 0.0f, 1.0f, 1.0f);
                    }
                    else
                    {
                        gfx::drawRectangle(pos, 0.0f, size, getTileColor(tileType));
                    }
                    continue;
                }

                // Tileset UV tiles (6/7 etc.)
                float u0{}, v0{}, u1{}, v1{};
                AEGfxTexture* tex = sprite::tileset();
                if (tex && sprite::getTileUv(tileType, u0, v0, u1, v1))
                    gfx::drawSprite(tex, pos, 0.0f, size, u0, v0, u1, v1);
                else
                    gfx::drawRectangle(pos, 0.0f, size, getTileColor(tileType));
            }
        }
    }

    static bool reachedGoalTopRight(const Player& p)
    {
        constexpr int goalCol = 31;
        constexpr int goalRow = 19;
        constexpr int gridRows = 20;
        constexpr int gridCols = 32;

        float xWorld{}, yWorld{}, cellW{}, cellH{};
        gridToWorld(goalCol, goalRow, gridCols, gridRows, xWorld, yWorld, cellW, cellH);

        float cx = xWorld + cellW * 0.5f;
        float cy = yWorld + cellH * 0.5f;

        float dx = p.pos.x - cx;
        float dy = p.pos.y - cy;

        return (std::sqrt(dx * dx + dy * dy) < cellW * 1.0f);
    }
}

namespace game
{
    // ---------------- Tutorial 1 ----------------
    Tutorial1::Tutorial1()
    {
        level::loadTileMap("Assets/Levels/tutorial_1.txt", 20, 32, &tileMap[0][0]);
    }

    int (*Tutorial1::getTileMap())[32] { return tileMap; }

    int Tutorial1::update(float dt)
    {
        if (AEInputCheckTriggered(AEVK_G)) gridVisible = !gridVisible;
        if (AEInputCheckTriggered(AEVK_ESCAPE)) return 2;

        PlayerUpdate(gGame.player, dt);
        sprite::updateAnimatedTiles(dt);

        if (reachedGoalTopRight(gGame.player)) return 30; // -> Tutorial2
        return 0;
    }

    void Tutorial1::draw() const
    {
        AEGfxSetBackgroundColor(0, 0, 0);
        drawTilesFromMap(tileMap);
        if (gridVisible) drawGridLines(32, 20);

        printText(-0.95f, 0.9f, 0xFFFFFFFFu, "Tutorial 1");
        printText(-0.95f, 0.8f, 0xFFFFFFFFu, "G: grid   ESC: menu");

        PlayerDraw(gGame.player);
    }

    // ---------------- Tutorial 2 ----------------
    Tutorial2::Tutorial2()
    {
        level::loadTileMap("Assets/Levels/tutorial_2.txt", 20, 32, &tileMap[0][0]);
    }

    int (*Tutorial2::getTileMap())[32] { return tileMap; }

    int Tutorial2::update(float dt)
    {
        if (AEInputCheckTriggered(AEVK_G)) gridVisible = !gridVisible;
        if (AEInputCheckTriggered(AEVK_ESCAPE)) return 2;

        PlayerUpdate(gGame.player, dt);
        sprite::updateAnimatedTiles(dt);

        if (reachedGoalTopRight(gGame.player)) return 31; // -> Tutorial3
        return 0;
    }

    void Tutorial2::draw() const
    {
        AEGfxSetBackgroundColor(0, 0, 0);
        drawTilesFromMap(tileMap);
        if (gridVisible) drawGridLines(32, 20);

        printText(-0.95f, 0.9f, 0xFFFFFFFFu, "Tutorial 2");
        PlayerDraw(gGame.player);
    }

    // ---------------- Tutorial 3 ----------------
    Tutorial3::Tutorial3()
    {
        level::loadTileMap("Assets/Levels/tutorial_3.txt", 20, 32, &tileMap[0][0]);
    }

    int (*Tutorial3::getTileMap())[32] { return tileMap; }

    int Tutorial3::update(float dt)
    {
        if (AEInputCheckTriggered(AEVK_G)) gridVisible = !gridVisible;
        if (AEInputCheckTriggered(AEVK_ESCAPE)) return 2;

        PlayerUpdate(gGame.player, dt);
        sprite::updateAnimatedTiles(dt);

        if (reachedGoalTopRight(gGame.player)) return 32; // -> WinterS1
        return 0;
    }

    void Tutorial3::draw() const
    {
        AEGfxSetBackgroundColor(0, 0, 0);
        drawTilesFromMap(tileMap);
        if (gridVisible) drawGridLines(32, 20);

        printText(-0.95f, 0.9f, 0xFFFFFFFFu, "Tutorial 3");
        PlayerDraw(gGame.player);
    }
}
