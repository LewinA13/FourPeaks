#ifndef SUMMERS2HPP
#define SUMMERS2HPP

#include <vector>
#include <cstdint>
#include "sprite.hpp"   // tileset/spikes/background textures
#include <cmath>        // std::round

typedef uint32_t u32;

namespace game {
    class SummerS2 {
    public:
        SummerS2();
        ~SummerS2();
        SummerS2(const SummerS2&) = delete;
        int update(float dt);
        void draw() const;

    private:
        bool gridVisible;

        // Grid dimensions - 32 columns width x 20 rows height.
        static const int gridCols = 32;
        static const int gridRows = 20;


        // Tile map: 0=empty, 1=ground, 2=spikes, etc.
        int tileMap[gridRows][gridCols];
        u32 getTileColor(int tileType) const;


        void drawGrid() const;
        void drawTiles() const;
        void gridToWorld(int col, int row, float& xWorld, float& yWorld, float& cellW, float& cellH) const;
    };
}

#endif // SUMMERS1HPP
