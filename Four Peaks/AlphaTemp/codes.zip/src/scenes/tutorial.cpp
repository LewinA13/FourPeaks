﻿// ----------------------------------------------------------------------------
// Done By: Hong Yang, Arun, Skyler, Justin
// ----------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Copyright (C) 2026 Team Game++ (Four Peaks)
// All rights reserved.
//
// This file is part of the Four Peaks project. All code, design, and original
// assets are the work of LewinA and team members unless otherwise stated.
//
// Audio assets are sourced from Soundly and used under appropriate licensing.
//
// Reproduction, distribution, or modification of this file or its contents,
// in whole or in part, without prior written permission is strictly prohibited.
//
//---------------------------------------------------------------------------

#include "scenes/tutorial.hpp"
#include "AEEngine.h"
#include "engine/graphics.hpp"
#include "gameplay/player.hpp"
#include "core/gamestate.hpp"
#include "engine/sprite.hpp"
#include "core/level_loader.hpp"
#include "engine/camera.hpp"

#include <cstdint>
#include <cmath>

typedef std::uint32_t u32;
extern s8 gFontId;

namespace
{
    // ===================================================================
    // Print text with scale and ARGB color
    // ===================================================================
    static void printText(f32 x, f32 y, u32 argbColor, const char* text, f32 scale = 1.0f)
    {
        f32 a = ((argbColor >> 24) & 0xFF) / 255.0f;
        f32 r = ((argbColor >> 16) & 0xFF) / 255.0f;
        f32 g = ((argbColor >> 8) & 0xFF) / 255.0f;
        f32 b = ((argbColor >> 0) & 0xFF) / 255.0f;
        AEGfxPrint(gFontId, text, x, y, scale, r, g, b, a);
    }

    // ===================================================================
    // Get color for a specific tile type
    // ===================================================================
    static u32 getTileColor(int tileType)
    {
        switch (tileType)
        {
        case 6:  return 0xFF555555u;
        case 7:  return 0xFF888888u;
        case 2:  return 0xFFFF3333u;
        case 8:  return 0xFFFFFF00u;
        default: return 0x00000000u;
        }
    }

    // ===================================================================
    // Convert grid coordinates to world coordinates
    // ===================================================================
    static void gridToWorld(int col, int row, int gridCols, int gridRows,
        float& xWorld, float& yWorld, float& cellW, float& cellH)
    {
        float minX = AEGfxGetWinMinX(), maxX = AEGfxGetWinMaxX();
        float minY = AEGfxGetWinMinY(), maxY = AEGfxGetWinMaxY();

        cellW = (maxX - minX) / static_cast<f32>(gridCols);
        cellH = (maxY - minY) / static_cast<f32>(gridRows);

        xWorld = minX + col * cellW;
        yWorld = minY + row * cellH;
    }

    // ===================================================================
    // Draw grid lines over the screen
    // ===================================================================


    static AEGfxTexture* portalTexture()
    {
        static AEGfxTexture* tex = []() -> AEGfxTexture*
        {
            AEGfxTexture* loaded = AEGfxTextureLoad("Assets/objects_/portal.png");
            if (!loaded) loaded = AEGfxTextureLoad("Assets/objects/portal.png");
            if (!loaded) loaded = AEGfxTextureLoad("Assets/portal.png");
            if (!loaded) loaded = AEGfxTextureLoad("portal.png");
            return loaded;
        }();
        return tex;
    }

    static void drawPortalIndicatorRect(float centerX, float centerY, float areaW, float areaH)
    {
        static float portalAnimTime = 0.0f;
        portalAnimTime += 1.0f / 60.0f;

        const bool horizontal = areaW > areaH;
        const float pulse = 0.94f + 0.06f * std::sin(portalAnimTime * 3.5f);

        auto maxf = [](float a, float b) { return (a > b) ? a : b; };

        AEGfxTexture* portalTex = portalTexture();
        if (portalTex)
        {
            constexpr int frameCount = 8;
            const int frame = static_cast<int>(portalAnimTime * 12.0f) % frameCount;
            const float u0 = static_cast<float>(frame) / static_cast<float>(frameCount);
            const float u1 = static_cast<float>(frame + 1) / static_cast<float>(frameCount);

            gfx::Vec2 portalSize{};
            if (horizontal)
            {
                // Keep the portal horizontal instead of rotating it, so it stays portal-shaped.
                portalSize.x = maxf(areaW * 1.05f, areaH * 2.40f);
                portalSize.y = maxf(areaH * 1.10f, areaW * 0.32f);
            }
            else
            {
                portalSize.x = maxf(areaW * 1.10f, areaH * 0.50f);
                portalSize.y = maxf(areaH * 1.10f, areaW * 2.00f);
            }

            const float rotation = 0.0f;
            gfx::drawSprite(portalTex, { centerX, centerY }, rotation,
                { portalSize.x * pulse, portalSize.y * pulse },
                u0, 0.0f, u1, 1.0f, 1.0f);
        }
        else
        {
            gfx::drawRectangle({ centerX, centerY }, 0.0f,
                { areaW * (horizontal ? 1.00f : 0.80f), areaH * (horizontal ? 0.80f : 1.00f) },
                0xAA66CCFFu);
        }
    }

    static void drawPortalIndicatorCells(int startCol, int endCol, int startRow, int endRow,
        int gridCols = 32, int gridRows = 20)
    {
        float minX = AEGfxGetWinMinX(), maxX = AEGfxGetWinMaxX();
        float minY = AEGfxGetWinMinY(), maxY = AEGfxGetWinMaxY();
        const float cellW = (maxX - minX) / static_cast<float>(gridCols);
        const float cellH = (maxY - minY) / static_cast<float>(gridRows);

        const float left = minX + startCol * cellW;
        const float right = minX + (endCol + 1) * cellW;
        const float bottom = minY + startRow * cellH;
        const float top = minY + (endRow + 1) * cellH;

        drawPortalIndicatorRect(std::round((left + right) * 0.5f),
            std::round((bottom + top) * 0.5f),
            right - left, top - bottom);
    }

    static void drawGridLines(int gridCols, int gridRows)
    {
        const u32 gridColor = 0x80FFFFFF;

        float minX = AEGfxGetWinMinX(), maxX = AEGfxGetWinMaxX();
        float minY = AEGfxGetWinMinY(), maxY = AEGfxGetWinMaxY();

        float cellW = (maxX - minX) / static_cast<f32>(gridCols);
        float cellH = (maxY - minY) / static_cast<f32>(gridRows);
        float thickness = (cellW < cellH ? cellW : cellH) * 0.04f;

        for (int col = 0; col <= gridCols; ++col)
        {
            float x = minX + col * cellW;
            gfx::drawRectangle({ x, (minY + maxY) * 0.5f }, 0.0f, { thickness, maxY - minY }, gridColor);
        }
        for (int row = 0; row <= gridRows; ++row)
        {
            float y = minY + row * cellH;
            gfx::drawRectangle({ (minX + maxX) * 0.5f, y }, 0.0f, { maxX - minX, thickness }, gridColor);
        }
    }

    // ---------------------------------------------------------------
    // drawTilesFromMap
    // All original sprites are preserved exactly.
    // Solid tiles (1,3,5,6,7,23) fall through to the border pass.
    // All non-solid tiles (spikes, sign, animated, crack) use continue.
    // ---------------------------------------------------------------
    static void drawTilesFromMap(const int tileMap[20][32])
    {
        constexpr int gridRows = 20;
        constexpr int gridCols = 32;

        auto isSolid = [&](int r, int c) -> bool {
            if (r < 0 || r >= gridRows || c < 0 || c >= gridCols) return false;
            int t = tileMap[r][c];
            return (t == 1 || t == 3 || t == 4 || t == 5 || t == 6 || t == 7 || t == 23);
            };

        for (int row = 0; row < gridRows; ++row)
        {
            for (int col = 0; col < gridCols; ++col)
            {
                int tileType = tileMap[row][col];
                if (tileType <= 0) continue;

                float xWorld{}, yWorld{}, cellW{}, cellH{};
                gridToWorld(col, row, gridCols, gridRows, xWorld, yWorld, cellW, cellH);

                gfx::Vec2 pos{ std::round(xWorld + cellW * 0.5f), std::round(yWorld + cellH * 0.5f) };
                gfx::Vec2 size{ cellW, cellH };

                float border = (cellW < cellH ? cellW : cellH) * 0.05f;
                u32   borderColor = 0xFF000000;

                // ---- Animated tiles (melon=8, checkpoint=10) — not solid ----
                if (sprite::drawAnimatedTile(tileType, pos, size))
                    continue;

                // ---- Up-facing spike (2) ----
                if (tileType == 2)
                {
                    AEGfxTexture* spikeTex = sprite::spikes();
                    if (spikeTex)
                    {
                        gfx::Vec2 spikeSize{ size.x, size.y * 1.5f };
                        gfx::Vec2 spikePos = pos;
                        spikePos.y += (spikeSize.y - size.y) * 0.5f;
                        gfx::drawSprite(spikeTex, spikePos, 0.0f, spikeSize, 0.0f, 0.0f, 1.0f, 1.0f);
                    }
                    else gfx::drawRectangle(pos, 0.0f, size, getTileColor(tileType));
                    continue;
                }

                // ---- Down-facing spike (9) ----
                if (tileType == 9)
                {
                    AEGfxTexture* spikeTex = sprite::spikes();
                    if (spikeTex)
                    {
                        gfx::Vec2 spikeSize{ size.x, size.y * 1.5f };
                        gfx::Vec2 spikePos = pos;
                        spikePos.y -= (spikeSize.y - size.y) * 0.5f;
                        gfx::drawSprite(spikeTex, spikePos, 0.0f, spikeSize, 0.0f, 1.0f, 1.0f, 0.0f);
                    }
                    continue;
                }

                // ---- Cell-fit left spike (21) and right spike (22) ----
                if (tileType == 21 || tileType == 22)
                {
                    AEGfxTexture* spikeTex = sprite::spikes();
                    if (spikeTex)
                    {
                        gfx::Vec2 ss{ size.y, size.x };
                        gfx::Vec2 sp = pos;
                        float u0 = 0.0f, v0 = 0.0f, u1 = 1.0f, v1 = 1.0f;
                        if (tileType == 22) { u0 = 1.0f; u1 = 0.0f; }
                        gfx::drawSprite(spikeTex, sp, 0.0f, ss, u0, v0, u1, v1);
                    }
                    continue;
                }

                // ---- Left-facing spike (26) and right-facing spike (27) ----
                if (tileType == 26 || tileType == 27)
                {
                    AEGfxTexture* spikeTex = sprite::spikes();
                    if (spikeTex)
                    {
                        gfx::Vec2 ss{ size.x * 1.5f, size.y };
                        gfx::Vec2 sp = pos;
                        float u0 = 0.0f, v0 = 0.0f, u1 = 1.0f, v1 = 1.0f;
                        if (tileType == 26) { sp.x += (ss.x - size.x) * 0.5f; }
                        else { sp.x -= (ss.x - size.x) * 0.5f; u0 = 1.0f; u1 = 0.0f; }
                        gfx::drawSprite(spikeTex, sp, 0.0f, ss, u0, v0, u1, v1);
                    }
                    continue;
                }

                // ---- Sign (19) — not solid ----
                if (tileType == 19)
                {
                    AEGfxTexture* tex = sprite::sign();
                    gfx::Vec2 signSize{ size.x * 0.9f, size.y * 1.05f };
                    gfx::Vec2 signPos{ pos.x, pos.y + (signSize.y - size.y) * 0.5f };
                    if (tex) gfx::drawSprite(tex, signPos, 0.0f, signSize, 0.0f, 0.0f, 1.0f, 1.0f);
                    else     gfx::drawRectangle(signPos, 0.0f, signSize, 0xFF88FF88u);
                    AEGfxSetRenderMode(AE_GFX_RM_COLOR);
                    AEGfxSetBlendMode(AE_GFX_BM_NONE);
                    continue;
                }

                // ----------------------------------------------------------------
                // Solid tiles — draw sprite then fall through to border pass below.
                // ----------------------------------------------------------------
                if (tileType == 23)
                {
                    AEGfxTexture* t = sprite::grass();
                    if (t) gfx::drawSprite(t, pos, 0.0f, size, 0, 0, 1, 1);
                    else   gfx::drawRectangle(pos, 0.0f, size, 0xFF00AA00u);
                }
                else if (tileType == 1)
                {
                    AEGfxTexture* t = sprite::spring1();
                    if (t) gfx::drawSprite(t, pos, 0.0f, size, 0, 0, 1, 1);
                    else   gfx::drawRectangle(pos, 0.0f, size, getTileColor(tileType));
                }
                else if (tileType == 3)
                {
                    AEGfxTexture* t = sprite::spring2();
                    if (t) gfx::drawSprite(t, pos, 0.0f, size, 0, 0, 1, 1);
                    else   gfx::drawRectangle(pos, 0.0f, size, getTileColor(tileType));
                }
                else if (tileType == 5)
                {
                    AEGfxTexture* t = sprite::autumn1();
                    if (t) gfx::drawSprite(t, pos, 0.0f, size, 0, 0, 1, 1);
                    else   gfx::drawRectangle(pos, 0.0f, size, getTileColor(tileType));
                }
                else if (tileType == 7)
                {
                    AEGfxTexture* t = sprite::autumn2();
                    if (t) gfx::drawSprite(t, pos, 0.0f, size, 0, 0, 1, 1);
                    else   gfx::drawRectangle(pos, 0.0f, size, getTileColor(tileType));
                }
                else if (tileType == 4)
                {
                    AEGfxTexture* t = sprite::winterC();
                    if (t) gfx::drawSprite(t, pos, 0.0f, size, 0, 0, 1, 1);
                    else   gfx::drawRectangle(pos, 0.0f, size, 0xFF808080u);
                }
                else if (tileType == 6)
                {
                    AEGfxTexture* t = sprite::winterT();
                    if (t) gfx::drawSprite(t, pos, 0.0f, size, 0, 0, 1, 1);
                    else   gfx::drawRectangle(pos, 0.0f, size, 0xFF555555u);
                }
                else
                {
                    // Tileset UV fallback for any other tile IDs
                    float u0{}, v0{}, u1{}, v1{};
                    AEGfxTexture* tex = sprite::tileset();
                    if (tex && sprite::getTileUv(tileType, u0, v0, u1, v1))
                        gfx::drawSprite(tex, pos, 0.0f, size, u0, v0, u1, v1);
                    else
                        gfx::drawRectangle(pos, 0.0f, size, getTileColor(tileType));
                }

                // ---- Borders (solid tiles only) ----
                if (!isSolid(row, col)) continue;

                if (!isSolid(row + 1, col))
                    gfx::drawRectangle({ pos.x, pos.y + size.y * 0.5f - border * 0.5f }, 0.0f, { size.x, border }, borderColor);
                if (!isSolid(row - 1, col))
                    gfx::drawRectangle({ pos.x, pos.y - size.y * 0.5f + border * 0.5f }, 0.0f, { size.x, border }, borderColor);
                if (!isSolid(row, col - 1))
                    gfx::drawRectangle({ pos.x - size.x * 0.5f + border * 0.5f, pos.y }, 0.0f, { border, size.y }, borderColor);
                if (!isSolid(row, col + 1))
                    gfx::drawRectangle({ pos.x + size.x * 0.5f - border * 0.5f, pos.y }, 0.0f, { border, size.y }, borderColor);
            }
        }
    }

    // ---------------------------------------------------------------
    // Tutorial background
    // ---------------------------------------------------------------
    static void drawTutorialBackground()
    {
        AEGfxTexture* bg = sprite::tutorialBackground();
        if (!bg) return;

        float minX = AEGfxGetWinMinX(), maxX = AEGfxGetWinMaxX();
        float minY = AEGfxGetWinMinY(), maxY = AEGfxGetWinMaxY();

        gfx::drawSprite(bg,
            { (minX + maxX) * 0.5f, (minY + maxY) * 0.5f }, 0.0f,
            { maxX - minX, maxY - minY },
            0.0f, 0.0f, 1.0f, 1.0f);
    }

    // ---------------------------------------------------------------
    // Tutorial navigation buttons
    // ---------------------------------------------------------------
    struct UiButton
    {
        const char* label;
        f32 x, y, w, h;
        int action;
    };

    // ===================================================================
    // Get mouse position normalized to [-1,1] x [-1,1]
    // ===================================================================
    static void getMouseNormalized(f32& nx, f32& ny)
    {
        s32 mx = 0, my = 0;
        AEInputGetCursorPosition(&mx, &my);

        const f32 w = (f32)AEGfxGetWindowWidth();
        const f32 h = (f32)AEGfxGetWindowHeight();

        nx = (w > 0.0f) ? ((mx / w) * 2.0f - 1.0f) : 0.0f;
        ny = (h > 0.0f) ? (1.0f - (my / h) * 2.0f) : 0.0f;
    }

    // ===================================================================
    // Check if point is inside a UI button
    // ===================================================================
    static bool pointInRect(f32 px, f32 py, const UiButton& b)
    {
        return (px >= b.x && px <= (b.x + b.w) && py >= b.y && py <= (b.y + b.h));
    }

    // ===================================================================
    // Tutorial navigation handling
    // ===================================================================
    static int tutorialNavButtons(int currentTutorial)
    {
        UiButton buttons[] =
        {
            { "T2", 0.55f, 0.90f, 0.10f, 0.07f, 30 },
            { "T3", 0.67f, 0.90f, 0.10f, 0.07f, 31 },
            { "W1", 0.79f, 0.90f, 0.12f, 0.07f, 32 },
        };

        printText(0.55f, 0.90f, 0xFFFFFFFFu, "[T2]", 1.0f);
        printText(0.67f, 0.90f, 0xFFFFFFFFu, "[T3]", 1.0f);
        printText(0.79f, 0.90f, 0xFFFFFFFFu, "[W1]", 1.0f);

        (void)currentTutorial;


        if (!AEInputCheckTriggered(AEVK_LBUTTON))
            return 0;

        f32 mxN{}, myN{};
        getMouseNormalized(mxN, myN);

        for (const UiButton& b : buttons)
            if (pointInRect(mxN, myN, b))
                return b.action;

        return 0;
    }

} // anonymous namespace

namespace game
{
    // ---------------------------------------------------------------
    // Tutorial 1
    // ---------------------------------------------------------------
    Tutorial1::Tutorial1()
    {
        level::loadTileMap("Assets/Levels/tutorial_1.txt", 20, 32, &tileMap[0][0]);
    }

    // ===================================================================
    // Tutorial1::getTileMap
    // ===================================================================
    int (*Tutorial1::getTileMap())[32] { return tileMap; }

    // ===================================================================
    // Tutorial1::update
    // ===================================================================
    int Tutorial1::update(float dt)
    {
        if (AEInputCheckTriggered(AEVK_G))      gridVisible = !gridVisible;

        if (int nav = tutorialNavButtons(1)) return nav;

        PlayerUpdate(gGame.player, dt);
        sprite::updateAnimatedTiles(dt);

        if (!camera::isTransitioning())
        {
            float gx{}, gy{}, cw{}, ch{};
            gridToWorld(1, 19, this->gridCols, this->gridRows, gx, gy, cw, ch);
            float dx = gGame.player.pos.x - (gx + cw * 0.5f);
            float dy = gGame.player.pos.y - (gy + ch * 0.5f);
            if (std::sqrt(dx * dx + dy * dy) < cw * 1.5f) return 30;
        }
        return 0;
    }

    // ===================================================================
    // Tutorial1::draw
    // ===================================================================
    void Tutorial1::draw() const
    {
        AEGfxSetBackgroundColor(0, 0, 0);
        drawTutorialBackground();
        drawTilesFromMap(tileMap);
        if (gridVisible) drawGridLines(32, 20);

        // Teleporter visual: T1 col1-2, row19
        drawPortalIndicatorCells(1, 2, 19, 19);

        PlayerDraw(gGame.player, gridVisible);
    }

    // ---------------------------------------------------------------
    // Tutorial 2
    // ---------------------------------------------------------------
    Tutorial2::Tutorial2()
    {
        level::loadTileMap("Assets/Levels/tutorial_2.txt", 20, 32, &tileMap[0][0]);
    }

    // ===================================================================
    // Tutorial2::getTileMap
    // ===================================================================
    int (*Tutorial2::getTileMap())[32] { return tileMap; }

    // ===================================================================
    // Tutorial2::update
    // ===================================================================
    int Tutorial2::update(float dt)
    {
        if (AEInputCheckTriggered(AEVK_G))      gridVisible = !gridVisible;

        if (int nav = tutorialNavButtons(2)) return nav;

        PlayerUpdate(gGame.player, dt);
        sprite::updateAnimatedTiles(dt);

        if (!camera::isTransitioning())
        {
            float gx{}, gy{}, cw{}, ch{};
            gridToWorld(31, 3, this->gridCols, this->gridRows, gx, gy, cw, ch);
            float dx = gGame.player.pos.x - (gx + cw * 0.5f);
            float dy = gGame.player.pos.y - (gy + ch * 0.5f);
            if (std::sqrt(dx * dx + dy * dy) < cw * 1.5f) return 31;
        }
        return 0;
    }

    // ===================================================================
    // Tutorial2::draw
    // ===================================================================
    void Tutorial2::draw() const
    {
        AEGfxSetBackgroundColor(0, 0, 0);
        drawTutorialBackground();
        drawTilesFromMap(tileMap);
        if (gridVisible) drawGridLines(32, 20);

        // Teleporter visual: T2 col31, rows 3-4
        drawPortalIndicatorCells(31, 31, 3, 4);


        PlayerDraw(gGame.player, gridVisible);
    }

    // ---------------------------------------------------------------
    // Tutorial 3
    // ---------------------------------------------------------------
    Tutorial3::Tutorial3()
    {
        level::loadTileMap("Assets/Levels/tutorial_3.txt", 20, 32, &tileMap[0][0]);
    }

    // ================================================================== =
    // Tutorial3::getTileMap
    // ===================================================================
    int (*Tutorial3::getTileMap())[32] { return tileMap; }

    // ===================================================================
    // Tutorial3::update
    // ===================================================================
    int Tutorial3::update(float dt)
    {
        if (AEInputCheckTriggered(AEVK_G))      gridVisible = !gridVisible;

        if (int nav = tutorialNavButtons(3)) return nav;

        PlayerUpdate(gGame.player, dt);
        sprite::updateAnimatedTiles(dt);

        if (!camera::isTransitioning())
        {
            float gx{}, gy{}, cw{}, ch{};
            gridToWorld(31, 16, this->gridCols, this->gridRows, gx, gy, cw, ch);
            float dx = gGame.player.pos.x - (gx + cw * 0.5f);
            float dy = gGame.player.pos.y - (gy + ch * 0.5f);
            if (std::sqrt(dx * dx + dy * dy) < cw * 1.5f) return 32;
        }
        return 0;
    }

    // ===================================================================
    // Tutorial3::draw
    // ===================================================================
    void Tutorial3::draw() const
    {
        AEGfxSetBackgroundColor(0, 0, 0);
        drawTutorialBackground();
        drawTilesFromMap(tileMap);
        if (gridVisible) drawGridLines(32, 20);

        // Teleporter visual: T3 col31, rows 16-18
        drawPortalIndicatorCells(31, 31, 16, 18);

        PlayerDraw(gGame.player, gridVisible);
    }

} // namespace game 