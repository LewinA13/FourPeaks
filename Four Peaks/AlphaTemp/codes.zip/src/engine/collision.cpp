﻿// ----------------------------------------------------------------------------
// Done By: Hong Yang
// ----------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Copyright (C) 2026 Team Game++ (Four Peaks)
// All rights reserved.
//
// This file is part of the Four Peaks project. All code, design, and original
// assets are the work of LewinA and team members unless otherwise stated.
//
// Audio assets are sourced from Soundly and used under appropriate licensing.
//
// Reproduction, distribution, or modification of this file or its contents,
// in whole or in part, without prior written permission is strictly prohibited.
//
//---------------------------------------------------------------------------

#include "scenes/winter.hpp"
#include "gameplay/player.hpp"
#include <iostream>
#include "engine/collision.hpp"
#include "engine/audio.hpp"
#include "gameplay/dialogue.hpp"
#include "engine/graphics.hpp"
#include "core/gamestate.hpp"

// ---------------------------------------------------------------------------
// Globals
// ---------------------------------------------------------------------------
std::vector<breakableTileTrigger> g_triggeredIceTiles;
std::vector<breakableTileTrigger> g_triggeredbrkTiles;
std::string g_currentScene = "";

const int mapRows = 20;
const int mapColm = 32;

int tileW = 50;
int tileH = 45;

int   (*g_currentMap)[32] = nullptr;
int   g_currentSignID = 0;
float g_currentY = 0;

// ---------------------------------------------------------------------------
// Internal structs
// ---------------------------------------------------------------------------
struct TileRange {
    int colStart, colEnd;
    int rowStart, rowEnd;
};

// ---------------------------------------------------------------------------
// Player position helpers function
// ---------------------------------------------------------------------------
static float getPlayerScreenY(const Player& player)
{
    float halfWinH = (float)AEGfxGetWindowHeight() * 0.5f;
    return (player.pos.y + halfWinH) - g_currentY;
}

static float getPlayerFeetY(const Player& player)
{
    return getPlayerScreenY(player) - player.colliderSize.y * 0.5f;
}

static float getPlayerHeadY(const Player& player)
{
    return getPlayerScreenY(player) + player.colliderSize.y * 0.5f;
}

// ---------------------------------------------------------------------------
// Tile range calculation
// Converts player world position to tile grid indices.
// ---------------------------------------------------------------------------
TileRange calTileRange(f32 x, f32 y, f32 width, f32 height)
{
    TileRange box{};

    const float fullH = (float)AEGfxGetWindowHeight();
    const float halfH = fullH * 0.5f;
    const float halfW = (float)AEGfxGetWindowWidth() * 0.5f;

    // Convert center-origin to screen-space 
    float btmCoordPostX = x + halfW;
    float btmCoordPostY = y + halfH;

    // get a Y value that maps correctly to the tile grid of that stage
    float screenY = btmCoordPostY - g_currentY;

    // Invalidate if player is completely outside the current layer
    float playerBottom = screenY - height * 0.5f;
    if (playerBottom > fullH || screenY < 0) {
        box.colStart = box.colEnd = box.rowStart = box.rowEnd = -1;
        return box;
    }

    // +- 1.0f is to shrink player collider box
    float left = btmCoordPostX - width * 0.5f + 1.0f;
    float right = btmCoordPostX + width * 0.5f - 1.0f;
    float top = screenY + height * 0.5f - 1.0f;
    float bottom = screenY - height * 0.5f + 1.0f;

    box.colStart = static_cast<int>(left / tileW);
    box.colEnd = static_cast<int>(right / tileW);
    box.rowStart = static_cast<int>(bottom / tileH);
    box.rowEnd = static_cast<int>(top / tileH);

    // Clamp to map bounds
    box.colStart = max(box.colStart, 0);
    box.colEnd = min(box.colEnd, mapColm - 1);
    box.rowStart = max(box.rowStart, 0);
    box.rowEnd = min(box.rowEnd, mapRows - 1);

    if (box.rowStart > box.rowEnd || box.colStart > box.colEnd)
        box.colStart = box.colEnd = box.rowStart = box.rowEnd = -1;

    return box;
}

// ---------------------------------------------------------------------------
// Solid tile check
// ---------------------------------------------------------------------------
static bool isSolidTile(int tile)
{
    switch (tile) {
    case 1:   // ice
    case 3:   // tile (brown)
    case 4:   // tile (grey)
    case 5:   // tile
    case 6:   // underground
    case 7:   // platform
    case 11:  // winter ice tile
    case 16:  // summer tile top
    case 17:  // summer tile bottom
    case 30:  // Spring tile
        return true;
    default:
        return false;
    }
}



// ---------------------------------------------------------------------------
// Map collision check
// playerHeadY : screen-space head Y, used for breakable tile upper-half collision
// ---------------------------------------------------------------------------
bool checkMapCollision(TileRange box, int levelLayout[][mapColm], float playerHeadY = 0.0f)
{
    if (box.colStart == -1) return false;

    for (int r = box.rowStart; r <= box.rowEnd; r++) {
        for (int c = box.colStart; c <= box.colEnd; c++) {
            int tile = levelLayout[r][c];

            if (tile == 15) {
                // Breakable tile (special case): only the upper half is solid.
                float tileMiddleY = r * tileH + tileH * 0.5f;
                if (playerHeadY >= tileMiddleY)
                    return true;
                continue;
            }

            if (isSolidTile(tile))
                return true;
        }
    }
    return false;
}


// -------------------------------------------------------------------------
// Sets the player's current ground type to the appropriate damage type when
// they overlap a hazard tile. The overlap logic differs per tile:
//   case 2 / 24 — floor spikes / fire: lethal when feet are below the safe zone.
//   case 9      — ceiling spikes: lethal when head is above the safe zone.
//   case 25     — saw blade: only lethal when the horizontal overlap exceeds 60 %.
// -------------------------------------------------------------------------
static void resolveDamageTile(Player& player, int r, int c, TileRange box, int tileCase)
{
    switch (tileCase)
    {
    case 2:
    case 24:
    {
        float tileDeadZoneY = (r + 0.6f) * tileH;
        float playerFeetY = getPlayerFeetY(player);
        bool  spikeNotAtFeet = (r != box.rowStart);
        Player::GroundType damageType = (tileCase == 24)? Player::GroundType::Fire : Player::GroundType::Spikes;

        if (spikeNotAtFeet) { //  means player center touch the sprikes alr
               player.currGroundType = damageType;
        }
        else {
            if (playerFeetY <= tileDeadZoneY) // up
                player.currGroundType = damageType;
        }
        break;
    }

    case 9:
    {
        float tileDeadZoneY = (r + 0.4f) * tileH;
        float playerHeadY = getPlayerHeadY(player);
        bool  spikeNotAtHead = (r != box.rowEnd);

        if (spikeNotAtHead) { //  means player center touch the sprikes alr
                player.currGroundType = Player::GroundType::Spikes;
        }
        else {
            if (playerHeadY >= tileDeadZoneY)
                    player.currGroundType = Player::GroundType::Spikes;
        }
        break;
    }

    case 25:
    {
        float halfWinW = (float)AEGfxGetWindowWidth() / 2.0f;
        float btmCoordPostX = player.pos.x + halfWinW;
        float playerLeft = btmCoordPostX - player.colliderSize.x / 2.0f;
        float playerRight = btmCoordPostX + player.colliderSize.x / 2.0f;
        float tileLeft = (float)(c * tileW);
        float tileRight = (float)((c + 1) * tileW);

        float overlapLeft = fmaxf(playerLeft, tileLeft);
        float overlapRight = fminf(playerRight, tileRight);
        float overlapRatio = (overlapRight - overlapLeft) / player.colliderSize.x;

        printf("[SAW] tile[%d][%d] playerLeft=%.1f playerRight=%.1f tileLeft=%.1f tileRight=%.1f overlap=%.1f ratio=%.2f\n",
            r, c, playerLeft, playerRight, tileLeft, tileRight, overlapRight - overlapLeft, overlapRatio);

        if (overlapRatio > 0.6f)
            player.currGroundType = Player::GroundType::Saw;

        break;
    }

   


    }
}



// ---------------------------------------------------------------------------
// Ground type detection
// Iterates over the player's tile box and applies gameplay effects per tile.
// ---------------------------------------------------------------------------

void checkGroundType(Player& player, TileRange box, int levelLayout[][mapColm])
{
    for (int r = box.rowStart; r <= box.rowEnd; r++) {
        for (int c = box.colStart; c <= box.colEnd; c++) {

            // immediately return if out of bound
            if (box.colStart == -1) return;  

            printf("Current levelLayout[%i][%i]: %i\n", r, c, levelLayout[r][c]);
            switch (levelLayout[r][c]) {

            case 10: // checkpoint
            {
                player.currGroundType = Player::GroundType::CheckPoint;

                float halfWinW = (float)AEGfxGetWindowWidth() * 0.5f;
                float halfWinH = (float)AEGfxGetWindowHeight() * 0.5f;
                int   stageLevel = static_cast<int>(
                    floorf((player.pos.y + halfWinH) / AEGfxGetWindowHeight()));

                gfx::Vec2 res;
                res.x = (c + 0.5f) * tileW - halfWinW;
                res.y = (stageLevel * AEGfxGetWindowHeight()) + ((r + 1.0f) * tileH - halfWinH);

                player.checkpointScene = g_currentScene;
                PlayerSetRespawn(player, res);
                PlayerSaveCheckpoint(player, "checkpoint.txt");
                break;
            }

            // Using "resolveDamageTile" to resolve all damaga tile 
            case 2: case 9: case 24: case 25: // upspikes / downspikes / fire / saw
                resolveDamageTile(player, r, c, box, levelLayout[r][c]);
                break;

            case 23: // grass
                if (player.currGroundType != Player::GroundType::Saw) // specific check, dont allow grass overlap saw
                {
                    player.currGroundType = Player::GroundType::Grass;
                }
                break;

            case 4: case 5: case 6: case 7: case 30: // normal solid tiles
                if (player.currGroundType != Player::GroundType::Saw) // specific check, dont allow normal tiles overlap saw
                {
                    player.currGroundType = Player::GroundType::Normal;
                }
                break;

      

            case 8:	// melon 
                // only collect once
                if (!IsMelonCollected(g_currentScene.c_str(), r, c))
                {
                    player.melonsCollected += 1;
                    MarkMelonCollected(g_currentScene.c_str(), r, c);

                    // remove from current in-memory map immediately
                    levelLayout[r][c] = 0;

                    // if player has not touched any checkpoint yet, create a valid save anchor
                    if (player.checkpointScene.empty())
                    {
                        player.checkpointScene = g_currentScene;
                        PlayerSetRespawn(player, PlayerGetFeetWorld(player));
                    }

                    if (player.melonsCollected >= 53 && !gGame.allMelonsAchievementShown)
                    {
                        gGame.allMelonsAchievementShown = true;
                        UI::gDialog.triggerAutoDialog(46);
                    }

                    PlayerSaveCheckpoint(player, "checkpoint.txt");
                }
                else
                {
                    // safety: if already collected, keep it removed
                    levelLayout[r][c] = 0;
                }
                break;

            //Issue Lies Here with Tile ID.
            case 1: // ice tile 
            {
                // Only trigger when player feet are near the tile top.
                // Prevents triggering when player brushes the tile from the side.
                float feetY = getPlayerFeetY(player);
                float tileTopY = static_cast<float>(r + 1) * static_cast<float>(tileH);

                // trigger when player feet are within the top 5% of the ice tile
                if (feetY >= tileTopY - static_cast<float>(tileH) * 0.05f) {
                    g_triggeredIceTiles.push_back({ r, c });
                    player.currGroundType = Player::GroundType::Ice;
                }

                break;
            }

            case 15: // breakable tile
            {
                // Mirror the upper-half solid logic in checkMapCollision.
                float feetY = getPlayerFeetY(player);
                float tileTopY = static_cast<float>(r + 1) * static_cast<float>(tileH);

                if (feetY >= tileTopY - static_cast<float>(tileH) * 0.05f)
                    g_triggeredbrkTiles.push_back({ r, c });
                break;
            }

            case 18: // water bottle
                player.heat = min(player.heat + 0.35f, player.maxHeat);
                levelLayout[r][c] = 0;
                break;

            case 19:
            {
                float halfW = (float)AEGfxGetWindowWidth() * 0.5f;
                float halfH = (float)AEGfxGetWindowHeight() * 0.5f;

                float signWorldX = (c + 0.5f) * tileW - halfW;
                float signWorldY = g_currentY - halfH + (r + 0.5f) * tileH;

                UI::gDialog.setSignPos(signWorldX, signWorldY);
                UI::gDialog.playerNearSignBoard(true);
                UI::gDialog.showForLevel(g_currentSignID);
                break;
            }
         

            case 34: // winter artifacts
                if (MarkArtifactCollected(0))
                    PlayerSaveCheckpoint(player, "checkpoint.txt");
                UI::gDialog.triggerAutoDialog(13);
                levelLayout[r][c] = 0;
                break;

            case 31: // summer artifacts
                if (MarkArtifactCollected(1))
                    PlayerSaveCheckpoint(player, "checkpoint.txt");
                UI::gDialog.triggerAutoDialog(23);
                levelLayout[r][c] = 0;
                break;

            case 32: // spring artifacts
                if (MarkArtifactCollected(2))
                    PlayerSaveCheckpoint(player, "checkpoint.txt");
                UI::gDialog.triggerAutoDialog(33);
                levelLayout[r][c] = 0;
                break;

            case 33: // autumn artifacts
                if (MarkArtifactCollected(3))
                    PlayerSaveCheckpoint(player, "checkpoint.txt");
                //UI::gDialog.triggerFromArtifact(44);
                UI::gDialog.triggerAutoDialog(44);
                levelLayout[r][c] = 0;
                break;

            default:
                break;
            }
        }
    }
}

// -------------------------------------------------------------------------
// Convenience wrapper that builds a TileRange at the given world-space position
// and tests it against g_currentMap. Returns true if any solid tile overlaps.
// -------------------------------------------------------------------------
static bool checkAABBCollisionAt(float x, float y, float w, float h)
{
    TileRange box = calTileRange(x, y, w, h);
    return checkMapCollision(box, g_currentMap);
}

// ---------------------------------------------------------------------------
// Spawn resolution ? pushes player out of geometry after a respawn.
// ---------------------------------------------------------------------------
void CollisionResolveSpawn(Player& player)
{
    const float step = 0.5f;

    // Push up until clear
    TileRange box{};  
    for (int i = 0; i < 200; ++i) {
        box = calTileRange(player.pos.x, player.pos.y, player.colliderSize.x, player.colliderSize.y);
        if (!checkMapCollision(box, g_currentMap, getPlayerHeadY(player))) break;
        player.pos.y += step;
    }

    // Snap down a small amount so player lands on the surface
    const int maxSteps = (int)(10.0f / step);
    bool landed = false;
    for (int i = 0; i < maxSteps; ++i) {
        player.pos.y -= step;
        box = calTileRange(player.pos.x, player.pos.y, player.colliderSize.x, player.colliderSize.y);
        if (checkMapCollision(box, g_currentMap,getPlayerHeadY(player))) {
            player.pos.y += step;
            landed = true;
            break;
        }
    }

 
    player.grounded = landed;
    player.velX = 0.0f;
    player.velY = 0.0f;
    player.horzSpeed = 0.0f;
}

// ---------------------------------------------------------------------------
// Per-frame collision resolution
// ---------------------------------------------------------------------------
void resolvePlayerCollision(Player& player, int levelLayout[][mapColm], f32 dt)
{
    float currentY = player.pos.y;
    float oldY = currentY - player.velY * dt;

    // --- Horizontal collision ---
    // Temporarily revert to last frame Y so horizontal and vertical are resolved independently.
    player.pos.y = oldY;
    TileRange hBox = calTileRange(player.pos.x, player.pos.y, player.colliderSize.x, player.colliderSize.y);

    if (player.velX != 0.0f && checkMapCollision(hBox, levelLayout, getPlayerHeadY(player))) {
        float push = (player.velX > 0.0f) ? -0.5f : 0.5f;
        for (int i = 0; i < 200; ++i) {
            player.pos.x += push;
            hBox = calTileRange(player.pos.x, player.pos.y, player.colliderSize.x, player.colliderSize.y);
            if (!checkMapCollision(hBox, levelLayout, getPlayerHeadY(player))) {
                break;
            }
        }
        player.velX = 0.0f;
    }

    // Clamp to screen left / right borders
    const float halfWinW = (float)AEGfxGetWindowWidth() * 0.5f;
    const float halfPlayerW = player.colliderSize.x * 0.5f;
    if (player.pos.x - halfPlayerW < -halfWinW || player.pos.x + halfPlayerW > halfWinW) {
        player.pos.x = AEClamp(player.pos.x, -halfWinW + halfPlayerW, halfWinW - halfPlayerW);
        player.velX = 0.0f;
        player.horzSpeed = 0.0f;
    }

    // --- Vertical collision ---
    player.pos.y = currentY;

    const float halfWinH = (float)AEGfxGetWindowHeight() * 0.5f;     
    float fullH = (float)AEGfxGetWindowHeight();
    float btmCoordPostY = player.pos.y + fullH * 0.5f;
    float screenY = btmCoordPostY - g_currentY;

  
    float headY = getPlayerHeadY(player);

    if (headY > fullH)
    {
        float clampedHeadY = fullH;

        player.pos.y = (clampedHeadY - player.colliderSize.y * 0.5f) + g_currentY - halfWinH;

        player.velY = -100.0f;
    }


    // Kill player if they fall below the layer
    if (screenY < -50.0f) {
        PlayerKill(player);
        return;
    }

    float feetY = getPlayerFeetY(player);
    // GROUND_Y: the minimum screen-space Y before the player is considered out of bounds.
    // Derived from window height so it adapts if resolution changes.
    const float GROUND_Y = -(float)AEGfxGetWindowHeight() * 0.5f;

    TileRange vBox = calTileRange(player.pos.x, player.pos.y, player.colliderSize.x, player.colliderSize.y);


    if (feetY > GROUND_Y  && checkMapCollision(vBox, levelLayout, getPlayerHeadY(player))) {
        float push = (player.velY > 0) ? -0.5f : 0.5f;
        for (int i = 0; i < 200; ++i) {
            player.pos.y += push;
            vBox = calTileRange(player.pos.x, player.pos.y, player.colliderSize.x, player.colliderSize.y);
            if (!checkMapCollision(vBox, levelLayout, getPlayerHeadY(player))) {
                break;
            }
            
        }


        player.grounded = (player.velY < 0) ? true : player.grounded;
        player.velY = 0;
    }
}

// ---------------------------------------------------------------------------
// Ground physics 
// ---------------------------------------------------------------------------
void applyGroundPhysics(Player& player)
{
    switch (player.currGroundType) {
    case Player::GroundType::Normal:
        player.accel = 8.0f;
        player.decel = 4.0f;
        player.speed = 120.0f;
        break;

    case Player::GroundType::Spikes:
    case Player::GroundType::Saw:
    case Player::GroundType::Fire:
        PlayerKill(player);
        break;

    case Player::GroundType::Ice:
        player.accel = 25.0f;
        player.decel = 1.0f;
        break;

    case Player::GroundType::Grass:
        player.speed = 50.0f;
        break;

    default:
        break;
    }
}

// -------------------------------------------------------------------------
// Main per-frame collision driver. Resets the ground type to Normal, runs the
// tile overlap resolution, probes 2 px below the player for surface detection,
// and applies ground-type physics modifiers. Also restores normal air physics
// when the player is airborne.
// -------------------------------------------------------------------------
void CollisionUpdate(Player& player, f32 dt)
{

    player.currGroundType = Player::GroundType::Normal;
    resolvePlayerCollision(player, g_currentMap, dt);

    // Player has been pushed out of tiles by resolvePlayerCollision, 
    // and calTileRange shrinks the box by 1.0f at the bottom,
    // so probe 2.0f downward to ensure checkGroundType can detect the tile below player's feet
    TileRange box = calTileRange(player.pos.x, player.pos.y - 2.0f, player.colliderSize.x, player.colliderSize.y);
    checkGroundType(player, box, g_currentMap);

    applyGroundPhysics(player);

    if (!player.grounded) {
        player.accel = 8.0f;
        player.decel = 4.0f;
    }
}

// -------------------------------------------------------------------------
// Tests 2 px probes on either side of the player and updates the boolean wall
// flags used by the wall-slide and wall-jump logic in the player system.
// -------------------------------------------------------------------------
void CollisionUpdateWallFlags(Player& player)
{
    const float PROBE = 2.0f;
    float w = player.colliderSize.x;
    float h = player.colliderSize.y;

    player.onWallLeft = checkAABBCollisionAt(player.pos.x - PROBE, player.pos.y, w, h);
    player.onWallRight = checkAABBCollisionAt(player.pos.x + PROBE, player.pos.y, w, h);
}

// ---------------------------------------------------------------------------
// Dash checkpoint sampling
// Subdivides the dash path into segments to catch any tiles the player
// tunnelled through due to high speed.
// ---------------------------------------------------------------------------
void CheckPathForCheckpoint(Player& player, gfx::Vec2 startPos, gfx::Vec2 endPos) {
    const int numSamples = 10;
    // Slightly enlarged collider so checkpoint detection is less strict
    float fakeW = player.colliderSize.x + 5.0f;
    float fakeH = player.colliderSize.y + 5.0f;

    for (int i = 0; i <= numSamples; ++i) {
        float t = (float)i / (float)numSamples;
        float sx = startPos.x + (endPos.x - startPos.x) * t;
        float sy = startPos.y + (endPos.y - startPos.y) * t;

        TileRange box = calTileRange(sx, sy, fakeW, fakeH);
        checkGroundType(player, box, g_currentMap);
    }
}

// -------------------------------------------------------------------------
// Returns true only when solid tiles are detected simultaneously beneath both
// the left and right foot probe positions. This stricter test distinguishes a
// fully supported landing from a single-foot ledge contact.
// -------------------------------------------------------------------------
bool OnGroundExactly(Player& player)
{
    const float PROBE_Y = 2.0f;
    const float OFFSET_X = player.colliderSize.x * 0.4f; 

    float testW = 2.0f; 
    float testH = 2.0f;

    float leftX = player.pos.x - OFFSET_X;
    float rightX = player.pos.x + OFFSET_X;
    float y = player.pos.y - player.colliderSize.y * 0.5f - PROBE_Y;

    bool leftGround = checkAABBCollisionAt(leftX, y, testW, testH);
    bool rightGround = checkAABBCollisionAt(rightX, y, testW, testH);

    return leftGround && rightGround;
}